
module hu.unideb.inf.j08Expection01Emp {
	exports j08Expection01Emp;
}