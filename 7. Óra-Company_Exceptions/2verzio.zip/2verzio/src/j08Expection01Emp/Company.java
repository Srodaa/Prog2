package j08Expection01Emp;


import java.util.TreeSet;



/**
 * This is the Company class
 * @author {firstname=deik, last_name=it}
 * @see<a href="https://www.inf.unideb.hu">DEIK</a>
 */
public class Company {
	private String name;
	private String nameOfLeader;
	private TreeSet<Department> departments=new TreeSet<>();
	
	

	/**
	 * Constructor
	 * @param name: name of the company
	 * @param nameOfLeader: name of the leader of the company
	 */
	public Company(String name, String nameOfLeader) {
		super();
		this.name = name;
		this.nameOfLeader = nameOfLeader;
	}

	/**
	 * @return it returns the name of the leader of the company
	 */
	public String getNameOfLeader() {
		return nameOfLeader;
	}

	/**
	 * It sets the name of the leader of the company
	 * @param nameOfLeader: name of the leader of the company
	 */
	public void setNameOfLeader(String nameOfLeader) {
		this.nameOfLeader = nameOfLeader;
	}

	public String getName() {
		return name;
	}

	public TreeSet<Department> getDepartments() {
		return departments;
	}

	/**
	 * @param dept is a department
	 */
	public void addDepartment(Department dept) {
		departments.add(dept);
	}

	/**
	 * It removes a department 
	 * @param dept: a department
	 */
	public void removeDepartment(Department dept) {
		departments.remove(dept);
	}

	/**
	 *It is the toString method
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Company [name=");
		builder.append(name);
		builder.append(", nameOfLeader=");
		builder.append(nameOfLeader);
		builder.append(", departments=");
		builder.append(departments);
		builder.append("]");
		return builder.toString();
	}
	
	
}
