package j08Expection01Emp;

public class ShoeSizeException extends SizeException {

	public ShoeSizeException(String message) {
		super(message);
	}

}
