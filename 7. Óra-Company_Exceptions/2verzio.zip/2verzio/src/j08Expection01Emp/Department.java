package j08Expection01Emp;

import java.util.HashSet;
import java.util.Objects;





/**
 * This is the Department class
 * @author {firstname=deik, last_name=it}
 * @see<a href="https://www.inf.unideb.hu">DEIK</a>
 */


public class Department implements Comparable<Department>{
	private String id;
	private String name;
	private HashSet<Employee> employees=new HashSet<>();

	/**
	 * @param id: id of the department
	 * @param name: name of the department
	 */
	public Department(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	/**
	 * @return it return all employees of the deparment in a HashSet
	 */
	public HashSet<Employee> getEmployees() {
		return employees;
	}
	
	/**
	 * It adds an employee to the department. It sets the department to the employee also. 
	 * @param emp: an Employee object
	 * @throws DeptNotContainEmpException
	 */
	public void addEmployee(Employee emp) throws DeptNotContainEmpException {
		employees.add(emp);
		emp.setDepartment(this);
	}
	
	/**
	 * It remove an employee to the department. It sets the department of the employee to null also. 
	 * @param emp: an Employee object
	 * @throws DeptNotContainEmpException
	 */
	
	public void removeEmployee(Employee emp) throws DeptNotContainEmpException {
		employees.remove(emp);
		emp.setDepartment(null);
	}
	
	/**
	 * If the employee moves from a department to the other one, this static method can be used. 
	 * @param emp: the employee object who moves
	 * @param fromDept: from which department they move. 
	 * @param toDept: to which department they move. 
	 * @throws DeptNotContainEmpException the exception is asked the called method
	 */
	public static void employeeMove(Employee emp, Department fromDept, Department toDept) throws DeptNotContainEmpException  {
		fromDept.removeEmployee(emp);
		toDept.addEmployee(emp);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Department))
			return false;
		Department other = (Department) obj;
		return Objects.equals(id, other.id);
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Department [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", employees=");
		builder.append(employees);
		builder.append("]");
		return builder.toString();
	}
	@Override
	public int compareTo(Department o) {
		return this.id.compareTo(o.id);
	}
}
