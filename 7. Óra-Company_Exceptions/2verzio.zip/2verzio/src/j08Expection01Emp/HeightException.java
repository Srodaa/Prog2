package j08Expection01Emp;

public class HeightException extends SizeException {

	public HeightException(String message) {
		super(message);
	}

}
