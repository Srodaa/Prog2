package j08Expection01Emp;

public class DeptNotContainEmpException extends CompanyException {

	public DeptNotContainEmpException(String message) {
		super(message);
	}

}
