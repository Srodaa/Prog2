package j08Expection01Emp;


import java.time.LocalDate;
import java.util.Objects;

public class Person {
	private String name;
	private LocalDate birthDate;
	private String nickName;
	

	public Person(String name, LocalDate birthDate) throws WrongBirthDateExcception {
		super();
		this.name = name;
		if (birthDate.compareTo(LocalDate.now().minusYears(65))>=0 ||
				birthDate.compareTo(LocalDate.now().minusYears(18))<=0)
			this.birthDate = birthDate;
		else throw new WrongBirthDateExcception("The age should be between 18 and 65: "+birthDate);
	}

	public Person(String name, LocalDate birthDate, String nickName) throws WrongBirthDateExcception {
		this(name, birthDate);
		this.nickName = nickName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getName() {
		return name;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Person [name=");
		builder.append(name);
		builder.append(", birthDate=");
		builder.append(birthDate);
		builder.append(", nickName=");
		builder.append(nickName);
		builder.append("]");
		return builder.toString();
	}

	
	
}
